package com.example.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration(proxyBeanMethods = false)
public class TestProject123Application {

	public static void main(String[] args) {
		SpringApplication.from(Project123Application::main).with(TestProject123Application.class).run(args);
	}

}
